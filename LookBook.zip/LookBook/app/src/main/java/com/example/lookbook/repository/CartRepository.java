package com.example.lookbook.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.lookbook.data.AppDatabase;
import com.example.lookbook.data.CartDao;
import com.example.lookbook.data.model.CartItem;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CartRepository {

    private CartDao cartDao;
    private LiveData<List<CartItem>> allCartItems;
    private ExecutorService executorService;

    public CartRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        cartDao = database.cartDao();
        allCartItems = cartDao.getAllCartItems();
        executorService = Executors.newFixedThreadPool(2);
    }

    public void insert(CartItem cartItem) {
        executorService.execute(() -> cartDao.insert(cartItem));
    }

    public void delete(CartItem cartItem) {
        executorService.execute(() -> cartDao.delete(cartItem));
    }

    public LiveData<List<CartItem>> getAllCartItems() {
        return allCartItems;
    }
}
