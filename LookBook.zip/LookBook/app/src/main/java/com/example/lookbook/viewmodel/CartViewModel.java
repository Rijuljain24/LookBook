package com.example.lookbook.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.lookbook.data.model.CartItem;
import com.example.lookbook.repository.CartRepository;

import java.util.List;

public class CartViewModel extends AndroidViewModel {

    private CartRepository repository;
    private LiveData<List<CartItem>> allCartItems;

    public CartViewModel(@NonNull Application application) {
        super(application);
        repository = new CartRepository(application);
        allCartItems = repository.getAllCartItems();
    }

    public LiveData<List<CartItem>> getAllCartItems() {
        return allCartItems;
    }

    public void insert(CartItem cartItem) {
        repository.insert(cartItem);
    }

    public void delete(CartItem cartItem) {
        repository.delete(cartItem);
    }
}