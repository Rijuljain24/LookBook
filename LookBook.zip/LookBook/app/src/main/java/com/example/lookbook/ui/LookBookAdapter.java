package com.example.lookbook.ui;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lookbook.R;
import com.example.lookbook.data.model.LookBook;

import java.util.List;

public class LookBookAdapter extends RecyclerView.Adapter<LookBookAdapter.LookBookViewHolder> {

    private Context context;
    private List<LookBook> lookBooks;
    private OnItemClickListener listener;

    public LookBookAdapter(Context context, List<LookBook> lookBooks) {
        this.context = context;
        this.lookBooks = lookBooks;
    }

    @NonNull
    @Override
    public LookBookViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.lookbook_layout, parent, false);
        return new LookBookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LookBookViewHolder holder, int position) {
        LookBook lookBook = lookBooks.get(position);
        holder.textViewName.setText(lookBook.getName());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null && position != RecyclerView.NO_POSITION) {
                listener.onItemClick(lookBook);
            }
        });
    }

    @Override
    public int getItemCount() {
        return lookBooks.size();
    }

    public void setLookBooks(List<LookBook> lookBooks) {
        this.lookBooks = lookBooks;
        notifyDataSetChanged();
    }

    public Iterable<? extends LookBook> getLookBooks() {
        return null;
    }

    public interface OnItemClickListener {
        void onItemClick(LookBook lookBook);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public static class LookBookViewHolder extends RecyclerView.ViewHolder {
        private TextView textViewName;

        public LookBookViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
        }
    }
}
