package com.example.lookbook.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.lookbook.R;
import com.example.lookbook.data.model.CartItem;
import com.example.lookbook.viewmodel.CartViewModel;
import com.squareup.picasso.Picasso;

public class ItemDetailActivity extends AppCompatActivity {

    private CartViewModel cartViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        ImageView itemImage = findViewById(R.id.itemImage);
        TextView itemName = findViewById(R.id.itemName);
        TextView itemPrice = findViewById(R.id.itemPrice);
        Button addToCartButton = findViewById(R.id.addToCartButton);

        String name = getIntent().getStringExtra("itemName");
        double price = getIntent().getDoubleExtra("itemPrice", 0);
        String imageUrl = getIntent().getStringExtra("itemImage");

        Picasso.get().load(imageUrl).into(itemImage);
        itemName.setText(name);
        itemPrice.setText("$" + price);

        cartViewModel = new ViewModelProvider(this).get(CartViewModel.class);

        addToCartButton.setOnClickListener(v -> {
            CartItem cartItem = new CartItem(name, price, imageUrl);
            cartViewModel.insert(cartItem);
        });
    }
}
