package com.example.lookbook.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lookbook.R;
import com.example.lookbook.data.model.LookBook;
import com.example.lookbook.viewmodel.LookBookViewModel;

import java.util.ArrayList;
import java.util.List;

public class LookBookActivity extends AppCompatActivity {

    private LookBookViewModel viewModel;
    private LookBookAdapter adapter;
    private EditText searchBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lookbook);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new LookBookAdapter(this, List.of());
        recyclerView.setAdapter(adapter);

        searchBar = findViewById(R.id.search_bar);
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filter(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        viewModel = new ViewModelProvider(this).get(LookBookViewModel.class);
        viewModel.getAllLookBooks().observe(this, lookBooks -> adapter.setLookBooks(lookBooks));
    }

    private void filter(String text) {
        List<LookBook> filteredList = new ArrayList<>();
        for (LookBook lookBook : adapter.getLookBooks()) {
            if (lookBook.getName().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(lookBook);
            }
        }
        adapter.setLookBooks(filteredList);
    }
}
