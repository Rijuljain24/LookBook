// data/LookBookDao.java
package com.example.lookbook.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.lookbook.data.model.LookBook;

import java.util.List;

@Dao
public interface LookBookDao {

    @Insert
    void insert(LookBook lookBook);

    @Query("SELECT * FROM lookbook_table")
    LiveData<List<LookBook>> getAllLookBooks();
}