// data/ItemDao.java
package com.example.lookbook.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.lookbook.data.model.Item;

import java.util.List;

@Dao
public interface ItemDao {

    @Insert
    void insert(Item item);

    @Query("SELECT * FROM item_table")
    LiveData<List<Item>> getAllItems();
}


