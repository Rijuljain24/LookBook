package com.example.lookbook.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.lookbook.data.AppDatabase;
import com.example.lookbook.data.ItemDao;
import com.example.lookbook.data.LookBookDao;
import com.example.lookbook.data.model.Item;
import com.example.lookbook.data.model.LookBook;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LookBookRepository {

    private ItemDao itemDao;
    private LookBookDao lookBookDao;
    private LiveData<List<Item>> allItems;
    private LiveData<List<LookBook>> allLookBooks;
    private ExecutorService executorService;

    public LookBookRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        itemDao = database.itemDao();
        lookBookDao = database.lookBookDao();
        allItems = itemDao.getAllItems();
        allLookBooks = lookBookDao.getAllLookBooks();
        executorService = Executors.newFixedThreadPool(2);
        insertSampleData();
    }

    public void insert(Item item) {
        executorService.execute(() -> itemDao.insert(item));
    }

    public LiveData<List<Item>> getAllItems() {
        return allItems;
    }

    public void insert(LookBook lookBook) {
        executorService.execute(() -> lookBookDao.insert(lookBook));
    }

    public LiveData<List<LookBook>> getAllLookBooks() {
        return allLookBooks;
    }

    private void insertSampleData() {
        executorService.execute(() -> {
            if (itemDao.getAllItems().getValue() == null || itemDao.getAllItems().getValue().isEmpty()) {
                // Add more sample items here
            }
        });
    }
}
