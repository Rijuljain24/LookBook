package com.example.lookbook.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.lookbook.data.model.Item;
import com.example.lookbook.data.model.LookBook;
import com.example.lookbook.repository.LookBookRepository;

import java.util.List;

public class LookBookViewModel extends AndroidViewModel {

    private LookBookRepository repository;
    private LiveData<List<Item>> allItems;
    private LiveData<List<LookBook>> allLookBooks;

    public LookBookViewModel(@NonNull Application application) {
        super(application);
        repository = new LookBookRepository(application);
        allItems = repository.getAllItems();
        allLookBooks = repository.getAllLookBooks();
    }

    public LiveData<List<Item>> getAllItems() {
        return allItems;
    }

    public LiveData<List<LookBook>> getAllLookBooks() {
        return allLookBooks;
    }

    public void insert(Item item) {
        repository.insert(item);
    }

    public void insert(LookBook lookBook) {
        repository.insert(lookBook);
    }
}
